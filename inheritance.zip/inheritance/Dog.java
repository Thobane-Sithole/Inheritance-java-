/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package oop.inheritance;

/**
 *
 * @author Thobane
 */
public class Dog extends Animal{
    private String name;
    
    public Dog(){
        
    }
    
    public Dog(String name){
        this.name = name;
    }
    
    public void bark(){
        System.out.println("Woof Woof");
    }
    
    public String displaySum(){
        return "Hello Siboniso how are you doing today";
    }

    
    void name() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
