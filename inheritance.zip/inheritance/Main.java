package oop.inheritance;

import java.time.LocalDate;
import java.time.LocalTime;
import javax.swing.JOptionPane;

public class Main{
    public static void main(String[] args) {
        Inherit myObj = new Inherit();
        
        myObj.makeNoise();
        myObj.getnum(6);
        
        LocalDate date = LocalDate.now();
        LocalTime time = LocalTime.now();
        
        System.out.println(date);
        System.out.println(time);
    }
}

interface MyInterface{
    public abstract void makeNoise();
    public abstract void getnum(int num);
}

class Inherit implements MyInterface{
    
    public void makeNoise(){
        System.out.println("Making noise");
    }
    public void getnum(int num){
        System.out.println("The number is " + num);
    }
}