/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package oop.inheritance;

/**
 *
 * @author Thobane
 */
public abstract class Animal {
    private String type;
    private String place;
    private String name;
    
    public Animal(){
        
    }
    
    public Animal(String type, String place, String name){
        this.type = type;
        this.place = place;
        this.name = name;
    }
    
    public void getAnimal(){
        System.out.println("Type: " + type);
    }
    public String getName(){
        return name;
    }
    public String displaySom(){
        return "Hello Thobane Sithole...";
    }
    
     
}
