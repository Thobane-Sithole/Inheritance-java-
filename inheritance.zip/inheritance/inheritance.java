/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package oop.inheritance;

import javax.swing.JOptionPane;

/**
 *
 * @author Thobane
 */
public class inheritance {
    public static void main(String[] args){
        
        Dog dog = new Dog();
        
        dog.displaySom();
        //dog.bark();
        
        //dog.displaySom();
        JOptionPane.showMessageDialog(null,dog.displaySom());
        JOptionPane.showMessageDialog(null,dog.displaySom());
    }
}
